//: Playground - noun: a place where people can play

import UIKit

func isPalindromString(str : String ) -> Bool {
    
    var i = 1
    for character in str.characters {
        let index = str.startIndex.advancedBy(str.characters.count - i)
        switch character {
        case str[index] :
            break
        default :
            return false
        }
        i += 1
    }
    return true
}

isPalindromString("sdds")

func deleteWhitespaceFromString(str : String) -> String {
    
    var stringWithoutWhitespace = ""
    var i = 0
    let arrWords = NSMutableArray()
    
    for char in str.characters {
        
        if char == " " {
            if stringWithoutWhitespace.characters.count > 0 {
                arrWords.addObject(stringWithoutWhitespace)
            }
            stringWithoutWhitespace = ""
        } else {
            stringWithoutWhitespace.append(char)
        }
        i += 1
    }
    
    return arrWords.componentsJoinedByString(" ")
}

deleteWhitespaceFromString(" fsdf fsdfds sdfsdf sdfdsfdf ")

class Tree {
    
    static var root : Tree?
    static var sf : Array<Int>? = Array()
    
    var leftNode : Tree?
    var rightNode : Tree?
    var daddy : Tree?
    
    
    var value : Int?
    
    init(value:Int!) {
        
        self.value = value
    }
    
    func addNode(node : Tree!) {
        
        if node == nil {
            return
        }
        
        if Tree.root == nil {
            Tree.root = node
        } else {
            
            if self.value > node.value {
                if self.leftNode == nil {
                    self.leftNode = node
                    self.leftNode?.daddy = self
                } else {
                    self.leftNode?.addNode(node)
                }
            } else {
                if self.value < node.value {
                    if self.rightNode == nil {
                        self.rightNode = node
                        self.rightNode?.daddy = self
                    } else {
                        self.rightNode?.addNode(node)
                    }
                }
            }
        }
    }
    
    func printTree() {
        
        if let nodeLeft = self.leftNode {
            nodeLeft.printTree()
        }
        
        Tree.sf?.append(value!)
        
        if let nodeRight = self.rightNode {
            nodeRight.printTree()
        }
    }
    
    func deleteValue(value : Int) {
        
        let node = self.find(value)
        
        if node.value == Tree.root?.value {
            if Tree.root?.leftNode != nil {
                Tree.root = Tree.root!.leftNode
                if let tree = node.rightNode {
                    Tree.root!.addNode(tree)
                }
                return
            } else if Tree.root?.rightNode != nil {
                Tree.root = Tree.root!.rightNode
                if let tree = node.leftNode {
                    Tree.root!.addNode(tree)
                }
                return
            }
            Tree.root = nil
        } else {
            
            let left = node.leftNode
            let right = node.rightNode
            
            if node.daddy?.leftNode?.value == node.value {
                node.daddy?.leftNode = nil
            } else {
                node.daddy?.rightNode = nil
            }
            Tree.root?.addNode(left)
            Tree.root?.addNode(right)
        }
    }
    
    func find(value : Int) -> Tree {
        
        if self.value > value {
            if self.leftNode == nil {
                return (self.leftNode?.find(value))!
            } else {
                return (self.leftNode?.find(value))!
            }
        } else
            if self.value < value {
                if self.rightNode == nil {
                    return (self.rightNode?.find(value))!
                } else {
                    return (self.rightNode?.find(value))!
                }
            } else {
                return self
        }
    }
}

var tree = Tree(value: 5)
var tree1 = Tree(value: 2)
var tree2 = Tree(value: 6)
var tree3 = Tree(value: 8)

tree.addNode(tree)
Tree.root!.addNode(tree1)
Tree.root!.addNode(tree2)
Tree.root!.addNode(tree3)

Tree.root?.deleteValue(5)

Tree.sf

Tree.root?.printTree()
Tree.sf